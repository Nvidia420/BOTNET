# qbot
Qbot Botnet. Telnet botnet, most powerfull and strong botnet. requirements: 2 linux server.
